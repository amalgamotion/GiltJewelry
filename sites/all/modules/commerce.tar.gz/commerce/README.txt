Drupal Commerce is packaged for download at http://drupal.org/project/commerce.

Learn more at http://www.drupalcommerce.org.

